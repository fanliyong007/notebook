# YangTemplate
A LaTeX template for daily papers.

Please use the latest version V1.0.
